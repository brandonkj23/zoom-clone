import signal
import socket
import sys
import pickle
import threading
from concurrent.futures.thread import ThreadPoolExecutor


class Client:
    def __init__(self, addr, conn):
        self.name = 'water'
        self.conn = conn
        self.addr = addr

    def set_name(self, name):
        self.name = name

class Message:
    def __init__(self):
        self.msg

class Server:

    def __init__(self, host="", port=40000, port2=40001):
        self.server_port = int(port)
        self.server_video_port = int(port2)
        self.bufsize=4096#4096 #65000
        self.executor = ThreadPoolExecutor(5)
        self.futures = dict()
        self.conns = {}
        try:
            self.ServerSocket = socket.socket(family=socket.AF_INET, type= socket.SOCK_STREAM)
        except :
            return None
        self.host = host


    def start(self):
        try:

            self.ServerSocket.bind((self.host, self.server_port))
            self.ServerSocket.listen(1)
            print("TCP Server is up and listening on port ", self.server_port)
        except OSError as ex:
            print(f"server bind failed: {ex.strerror}")
            exit(1)

        while(True):
            conn, addr = self.ServerSocket.accept()
            client_name, address = conn.recvfrom(self.bufsize)
            self.conns[client_name.decode()] = conn
            print(client_name.decode())
            future = self.executor.submit(self.process, conn, addr, client_name.decode())

    def broadcast(self, client_name, d):
        for id in self.conns:
            if id != client_name:
                message = pickle.dumps(d)
                self.conns[id].send(message)
    def broadcast_video(self, client_name ,data):
        for id in self.conns:
            if id != client_name:
                self.conns[id].send(pickle.dumps(data))
    def process(self, conn, addr, client_name):
        try:
            while True:
                message, address = conn.recvfrom(self.bufsize)
                d = pickle.loads(message)
                host, port = addr
                if 'packs' in d:
                    num_packs = d['packs']
                    self.broadcast(client_name, d)
                    for i in range(num_packs):
                        data, address = conn.recvfrom(self.bufsize)
                        self.broadcast_video(client_name, data)
                    continue
                print('hi')
                print(f"message from client[{host}:{str(port)}]:{d['msg']}")
                self.broadcast(client_name, d)
                if message == "exit" :
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break
                elif not message:
                    print(f"Closed connection from client[{host}:{str(port)}]\n")
                    conn.close()
                    break

        except Exception as ex:
            print(f"Error: {ex}")
            if conn!= None:
                conn.close()
                print(f"Closed connection from client[{host}:{str(port)}]\n")

    def stop(self):
        self.ServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)

    def stop(self, signal, frame):
        self.ServerSocket.close()
        print(f"server stopped!")
        sys.exit(0)


class VideoServer:

    def __init__(self, host="", port=40005, port2=40001):
        self.server_port = int(port)
        self.server_video_port = int(port2)
        self.bufsize=4096#4096 #65000
        self.executor = ThreadPoolExecutor(5)
        self.futures = dict()
        self.conns = {}
        #self.executor = ThreadPoolExecutor(5)
        #self.futures = dict()
        try:
            self.ServerSocket = socket.socket(family=socket.AF_INET, type= socket.SOCK_DGRAM)
        except :
            return None
        self.host = host


    def start(self):
        try:

            self.ServerSocket.bind((self.host, self.server_port))
            #self.ServerSocket.listen(1)
            print("TCP Server is up and listening on port ", self.server_port)
        except OSError as ex:
            print(f"server bind failed: {ex.strerror}")
            exit(1)

        while(True):
            client_name, address = self.ServerSocket.recvfrom(self.bufsize)
            print('hi')
            ##self.conns.append(conn)
            #self.conns[client_name.decode()] = address
            #future = self.executor.submit(self.process, address, client_name.decode())
            self.process()
            #client_name, address = self.ServerVideoSocket.recvfrom(self.bufsize)
            #self.clients.append(Client(conn, addr))
            #future = self.executor.submit(self.process_video, address, client_name.decode())
            #with ThreadPoolExecutor(5) as executor:
                #futures = []
                #futures.append(executor.submit(self.process, conn, addr))
            #self.futures
            #self.process(conn, addr)

    def broadcast(self, client_name, d):
        for id in self.conns:
            #if id != client_name:
            message = pickle.dumps(d)
            self.ServerSocket.sendto(message, self.conns[id])
            #print(message);
            #self.conns[id].send(str.encode(msg))
            #self.conns[id].send(str.encode(id))
    def broadcast_video(self, client_name ,data):
        for id in self.conns:
            #print('hi')
            #if id != client_name:
            #print('hello')
            #print(data)
            #self.conns[id].send(pickle.dumps(data))
            self.ServerSocket.sendto(pickle.dumps(data), self.conns[id])
    def process(self):
        try:
            while True:
                message, address = self.ServerSocket.recvfrom(self.bufsize)
                d = pickle.loads(message)
                if 'packs' in d:
                    num_packs = d['packs']
                    client_name = d['name']
                    if client_name not in self.conns:
                        self.conns[client_name] = address
                    #self.broadcast(client_name, d)
                    self.ServerSocket.sendto(pickle.dumps(d), address)
                    #print(num_packs)
                    for i in range(num_packs):
                        data, address = self.ServerSocket.recvfrom(self.bufsize)
                        self.ServerSocket.sendto(data, address)
                        #self.broadcast_video(client_name, data)
                    continue

        except:
            return None

def run():
    server = Server()
    vserver = VideoServer()
    signal.signal(signal.SIGINT, server.stop)

    if server!=None:
        server.start()
    #vserver.start()

if __name__=="__main__":
    run()