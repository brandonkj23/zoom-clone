import queue

import cs375.client.device_io
import socket
import sys
import threading
import pickle
import cv2
import math
import numpy as np

lock = threading.Lock()

class Client():
    def __init__(self, server='localhost', port=40000):
        self.name = 'client'
        self.server_port = int(port)
        self.server_addr = server
        self.bufsize = 4096#4096
        self.running = True
        self.video_q = queue.Queue(maxsize=10)
        self.display_video_q = queue.Queue(maxsize=10)
        try:
            self.clientSocket = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
        except:
            return None

    def send(self):
        try:
            self.clientSocket.sendto(str.encode(self.name), (self.server_addr, self.server_port))
            while True:
                message = input("Send a message to  " + self.server_addr + ":" + str(self.server_port) + ":")
                if "exit" in message:
                    self.clientSocket.shutdown(socket.SHUT_WR)
                    self.running = False
                    print("Bye!")
                    break
                elif not message:
                    self.clientSocket.shutdown(socket.SHUT_WR)
                    self.running = False
                    print("Bye!")
                    break
                d = {'name': self.name, 'msg': message}
                message = pickle.dumps(d)
                self.clientSocket.sendto(message, (self.server_addr, self.server_port))
        except:
            self.clientSocket.shutdown(socket.SHUT_WR)
            self.running = False
            print("Bye!")

    def send_video(self):

        try:
            while self.running:
                frame = self.video_q.get()
                window = {'name': self.name, 'frame': frame}
                self.display_video_q.put(window)
                frame = cv2.resize(frame, (640, 480))  # resize the frame
                encoded, buffer = cv2.imencode('.jpg', frame)

                buffer = buffer.tobytes()
                buffer_size = len(buffer)

                num_of_packs = 1
                if buffer_size > self.bufsize:
                    num_of_packs = math.ceil(buffer_size / self.bufsize)
                frame_info = {"packs": num_of_packs, "name": self.name}

                self.clientSocket.sendto(pickle.dumps(frame_info), (self.server_addr, self.server_port))
                left = 0
                right = self.bufsize

                for i in range(num_of_packs):
                    data = buffer[left:right]
                    left = right
                    right += self.bufsize
                    self.clientSocket.sendto(data, (self.server_addr, self.server_port))
        except:
            return None


    def receive_packs(self, name, d):
        num_packs = d['packs']
        for i in range(num_packs):
            data, address = self.clientSocket.recvfrom(self.bufsize)
            if i == 0:
                buffer = data
            else:
                buffer += data
        frame = np.frombuffer(buffer, dtype=np.uint8)
        frame = frame.reshape(frame.shape[0], 1)
        frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
        frame = cv2.flip(frame, 1)
        window = {'name': name + '1', 'frame': frame}
        if frame is not None and type(frame) == np.ndarray:
            self.display_video_q.put(window)

    def receive(self):
        while self.running:
            msg, clientAddress = self.clientSocket.recvfrom(self.bufsize + 4096)
            if len(msg)< 100:
                d = pickle.loads(msg)
                name = d['name']
                if 'packs' in d:
                    self.receive_packs(name, d)
                else:
                    message = d['msg']
                    print(f"\nmessage from {d['name']}:", d['msg'])


    def start(self):
        if self.clientSocket is None:
            sys.exit(-1)
        try:
            self.clientSocket.connect((self.server_addr, self.server_port))
        except OSError as ex:
            self.clientSocket.close()
            s = None
            print(f"cannot connect: {ex}")
            sys.exit(1)
        if self.clientSocket is None:
            print('could not open socket')
            sys.exit(1)
        rtext = threading.Thread(target=self.receive)
        stext = threading.Thread(target=self.send)
        rtext.start()
        stext.start()
        vid = input("do you want to video stream y/n: ")
        if vid == 'y':
            video_stream_thread = threading.Thread(target=cs375.client.device_io.video_stream, args=(self.video_q,))
            video_stream_thread.start()
            svideo = threading.Thread(target=self.send_video)
            svideo.start()
            while self.running:
                if self.display_video_q.qsize() > 0:
                    cs375.client.device_io.showVid(self.display_video_q.get())


def run():
    client = Client()
    name = input("Enter your nickname: ")
    client.name = name
    client.start()


if __name__ == "__main__":
    run()
