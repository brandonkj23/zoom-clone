import queue
import threading
import cv2
import imutils
import os
import numpy as np

from collections import deque

cam = None
qu = deque
q = queue.Queue(maxsize=10)

def video_stream(q):
    cam = cv2.VideoCapture(0)
    Width = 400
    while cam.isOpened():
        rval, frame = cam.read()
        frame = imutils.resize(frame,width = Width)
        q.put(frame)
    cam.release()

def showVid(window):
    name = window['name']
    frame = window['frame']
    if np.shape(frame) != ():
        cv2.imshow(name, frame)
    key = cv2.waitKey(20) & 0xFF
    if key == ord('q'):
        #break
        os._exit(1)
    cv2.destroyWindow(name)

if __name__ == '__main__':
    windowName = "Camera1"
    t1 = threading.Thread(target= video_stream, args=(windowName, 0))
    t1.start()
    showVid()

